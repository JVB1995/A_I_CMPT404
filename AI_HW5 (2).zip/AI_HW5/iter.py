numbers = [0,1,2,3,4,5]
squares =[x**2 for x in range(len(numbers))]
print numbers
print squares
