import numpy as np
from numpy import genfromtxt


def getDataSet():
    #read digits data and split it into X and y for training and testing
    Dataset = genfromtxt('features.csv',delimiter=' ')
    y = Dataset[:,0]
    X = Dataset[:,1:]

    Dataset2 = genfromtxt('features-t.csv', delimiter='  ')
    y_test = Dataset2[0]
    X_test = Dataset2[1]
    return X, y, X_test, y_test